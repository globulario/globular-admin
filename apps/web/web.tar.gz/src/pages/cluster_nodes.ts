// src/pages/cluster_nodes.ts
import {
  listClusterNodes,
  setNodeProfiles,
  getNodeReport,
  getNodeHealthDetail,
  type ClusterNode,
  type NodeReport,
  type Finding,
  type NodeCapabilities,
  type NodeHealthDetail,
  type NodeHealthCheck,
} from '@globular/backend'

function fmtBytes(bytes: number): string {
  if (!bytes) return '—'
  if (bytes >= 1e12) return `${(bytes / 1e12).toFixed(1)} TB`
  if (bytes >= 1e9)  return `${(bytes / 1e9).toFixed(1)} GB`
  if (bytes >= 1e6)  return `${(bytes / 1e6).toFixed(0)} MB`
  return `${bytes} B`
}

function profileTags(profiles: string[]): string {
  if (!profiles.length) return '<span style="color:var(--secondary-text-color)">—</span>'
  return profiles.map(p => `<span class="md-chip md-chip-tonal" style="margin-right:3px">${p}</span>`).join('')
}

function capsLine(caps: NodeCapabilities | null): string {
  if (!caps || caps.cpuCount === 0) return '<span style="color:var(--secondary-text-color)">—</span>'
  const diskPct = caps.diskBytes > 0 ? Math.round((1 - caps.diskFreeBytes / caps.diskBytes) * 100) : 0
  return `
    <div style="display:flex;flex-wrap:wrap;gap:14px;font-size:.82rem;color:var(--on-surface-color)">
      <span><strong>${caps.cpuCount}</strong> CPU${caps.cpuCount !== 1 ? 's' : ''}</span>
      <span><strong>${fmtBytes(caps.ramBytes)}</strong> RAM</span>
      <span>
        <strong>${fmtBytes(caps.diskBytes)}</strong> disk
        <span style="display:inline-block;width:48px;height:5px;background:var(--border-subtle-color);
          border-radius:3px;overflow:hidden;vertical-align:middle;margin:0 4px;">
          <span style="display:block;height:100%;width:${diskPct}%;border-radius:3px;
            background:color-mix(in srgb,var(--accent-color) 60%,transparent);"></span>
        </span>
        ${fmtBytes(caps.diskFreeBytes)} free
      </span>
    </div>`
}

// ─── Severity constants (numeric, from generated proto enums) ────────────────

const SEV_INFO     = 1
const SEV_WARN     = 2
const SEV_ERROR    = 3
const SEV_CRITICAL = 4

function sevColor(s: number): string {
  if (s >= SEV_CRITICAL) return 'var(--error-color)'
  if (s >= SEV_ERROR)    return '#f59e0b'
  if (s >= SEV_WARN)     return '#f59e0b'
  return 'var(--secondary-text-color)'
}

function sevLabel(s: number): string {
  if (s >= SEV_CRITICAL) return 'CRITICAL'
  if (s >= SEV_ERROR)    return 'ERROR'
  if (s >= SEV_WARN)     return 'WARN'
  if (s >= SEV_INFO)     return 'INFO'
  return 'UNKNOWN'
}

function badge(label: string, color: string): string {
  return `<span class="md-badge" style="--badge-color:${color}">${label}</span>`
}

function ageLabel(seconds: number): string {
  if (!seconds) return '—'
  if (seconds < 60)   return `${seconds}s`
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`
  return `${Math.floor(seconds / 3600)}h`
}

function worstSeverity(findings: Finding[]): number {
  return findings.reduce((max, f) => Math.max(max, f.severity), 0)
}

function statusBadge(status: string): string {
  const color =
    status === 'ready'      ? 'var(--success-color)' :
    status === 'converging' ? '#f59e0b' :
    status === 'degraded'   ? '#f97316' :
    status === 'unhealthy'  ? 'var(--error-color)' :
                              'var(--secondary-text-color)'
  return badge(status.toUpperCase(), color)
}

// ─── Component ────────────────────────────────────────────────────────────────

interface NodeRow {
  node: ClusterNode
  report: NodeReport | null
  error: string
}

class PageClusterNodes extends HTMLElement {
  private _rows: NodeRow[] = []
  private _loadError = ''
  private _loading = true
  private _selectedNodeId = ''
  private _refreshTimer: number | null = null
  private _editingProfiles = false
  private _savingProfiles = false
  private _saveError = ''
  private _healthDetail: NodeHealthDetail | null = null
  private _healthLoading = false
  private _healthError = ''

  connectedCallback() {
    this.style.display = 'block'
    this.render()
    this.load()
    this._refreshTimer = window.setInterval(() => this.load(), 30_000)
  }

  disconnectedCallback() {
    if (this._refreshTimer) clearInterval(this._refreshTimer)
  }

  private async load() {
    let nodes: ClusterNode[]
    try {
      nodes = await listClusterNodes()
      this._loadError = ''
    } catch (e: any) {
      this._loadError = e?.message || 'ClusterController unavailable'
      this._loading = false
      this.render()
      return
    }

    // Fetch doctor reports concurrently for all nodes
    const results = await Promise.allSettled(
      nodes.map(n => getNodeReport(n.nodeId))
    )

    this._rows = nodes.map((node, i) => {
      const res = results[i]
      return {
        node,
        report: res.status === 'fulfilled' ? res.value : null,
        error:  res.status === 'rejected'  ? ((res.reason as any)?.message || 'Doctor unavailable') : '',
      }
    })

    this._loading = false
    this.render()
  }

  private async loadHealthDetail(nodeId: string) {
    this._healthLoading = true
    this._healthError = ''
    this._healthDetail = null
    this.renderDetail()
    try {
      this._healthDetail = await getNodeHealthDetail(nodeId)
    } catch (e: any) {
      this._healthError = e?.message || 'Health detail unavailable'
    }
    this._healthLoading = false
    this.renderDetail()
  }

  private render() {
    this.innerHTML = `
      <style>
        .cn-wrap { padding: 16px; }
        .cn-header { display: flex; align-items: center; gap: 12px; margin-bottom: 4px; }
        .cn-header h2 { margin: 0; font: var(--md-typescale-headline-small); }
        .cn-subtitle { margin: 0.25rem 0 1rem; opacity: .85; font: var(--md-typescale-body-medium); }
        .cn-node-id  { font-family: monospace; font-size: .78rem; color: var(--secondary-text-color); }
        .cn-hostname { font-weight: 600; }
        .cn-empty { padding: 14px; font: var(--md-typescale-body-medium); font-style: italic; color: var(--secondary-text-color); }
        .cn-btn-refresh {
          border:        1px solid var(--border-subtle-color);
          background:    transparent;
          color:         var(--on-surface-color);
          border-radius: var(--md-shape-sm);
          padding:       3px 10px;
          cursor:        pointer;
          font:          var(--md-typescale-label-medium);
        }
        .cn-btn-refresh:hover { background: var(--md-state-hover); }
        .cn-detail-panel {
          background:    var(--md-surface-container-low);
          border:        1px solid var(--border-subtle-color);
          border-radius: var(--md-shape-md);
          box-shadow:    var(--md-elevation-1);
          overflow:      hidden;
          margin-bottom: 16px;
        }
        .cn-kv-list { font-size: .75rem; font-family: monospace; color: var(--secondary-text-color); }
        .cn-section-label {
          font-size: .72rem; font-weight: 700; text-transform: uppercase;
          letter-spacing: .06em; color: var(--secondary-text-color);
          padding: 8px 14px; background: var(--md-surface-container);
          border-bottom: 1px solid var(--border-subtle-color);
        }
        .cn-check-icon { display: inline-block; width: 14px; text-align: center; font-weight: 700; }
        .cn-check-ok   { color: var(--success-color); }
        .cn-check-fail { color: var(--error-color); }
      </style>

      <div class="cn-wrap">
        <div class="cn-header">
          <h2>Cluster Nodes</h2>
          <div style="flex:1"></div>
          <button class="cn-btn-refresh" id="btnRefresh">↻ Refresh</button>
        </div>
        <p class="cn-subtitle">Node inventory, health status, and diagnostic findings from ClusterDoctor.</p>

        ${this._loading ? `<p class="cn-empty">Loading nodes…</p>` : ''}

        ${this._loadError ? `
        <div class="md-banner-warn">
          Could not load nodes — ${this._loadError}
          <br><span style="font-size:.8em;opacity:.8">Ensure <code>cluster_controller.ClusterControllerService</code> is reachable.</span>
        </div>
        ` : ''}

        ${!this._loading && !this._loadError ? `
        <div class="md-panel">
          <div class="md-panel-header">
            <span>Nodes (${this._rows.length})</span>
          </div>
          ${this._rows.length > 0 ? `
          <table class="md-table">
            <thead>
              <tr>
                <th>Hostname</th>
                <th>Profiles</th>
                <th>Node ID</th>
                <th>Reachable</th>
                <th>Heartbeat Age</th>
                <th>Findings</th>
                <th>Worst Severity</th>
              </tr>
            </thead>
            <tbody class="md-interactive">
              ${this._rows.map(row => {
                const r = row.report
                const wSev = r ? worstSeverity(r.findings) : 0
                const findingCount = r ? r.findings.length : 0
                const selected = row.node.nodeId === this._selectedNodeId
                return `
                <tr data-node-id="${row.node.nodeId}" class="${selected ? 'selected' : ''}">
                  <td class="cn-hostname">${row.node.hostname || row.node.nodeId}</td>
                  <td>${profileTags(row.node.profiles)}</td>
                  <td class="cn-node-id">${row.node.nodeId}</td>
                  <td>${r
                    ? badge(r.reachable ? 'REACHABLE' : 'UNREACHABLE', r.reachable ? 'var(--success-color)' : 'var(--error-color)')
                    : badge('UNKNOWN', 'var(--secondary-text-color)')
                  }</td>
                  <td style="color:var(--secondary-text-color)">${r ? ageLabel(r.heartbeatAgeSeconds) : '—'}</td>
                  <td>${findingCount > 0
                    ? `<span style="font-weight:600">${findingCount}</span>`
                    : `<span style="color:var(--secondary-text-color)">0</span>`
                  }</td>
                  <td>${wSev > 0
                    ? badge(sevLabel(wSev), sevColor(wSev))
                    : `<span style="color:var(--success-color)">✓ OK</span>`
                  }</td>
                </tr>`
              }).join('')}
            </tbody>
          </table>
          ` : `<p class="cn-empty">No nodes registered.</p>`}
        </div>
        ` : ''}

        <div id="detail"></div>
      </div>
    `

    this.querySelector('#btnRefresh')?.addEventListener('click', () => this.load())

    // Row click → show findings detail
    this.querySelectorAll('.md-table tbody tr[data-node-id]').forEach(tr => {
      tr.addEventListener('click', () => {
        const nodeId = (tr as HTMLElement).dataset.nodeId ?? ''
        if (this._selectedNodeId === nodeId) {
          this._selectedNodeId = ''
          this._healthDetail = null
        } else {
          this._selectedNodeId = nodeId
          this.loadHealthDetail(nodeId)
        }
        this._editingProfiles = false
        this._saveError = ''
        this.renderDetail()
        // Update selected highlight without full re-render
        this.querySelectorAll('.md-table tbody tr[data-node-id]').forEach(r => {
          r.classList.toggle('selected', (r as HTMLElement).dataset.nodeId === this._selectedNodeId)
        })
      })
    })

    this.renderDetail()
  }

  private renderDetail() {
    const el = this.querySelector('#detail') as HTMLElement
    if (!el) return

    if (!this._selectedNodeId) {
      el.innerHTML = ''
      return
    }

    const row = this._rows.find(r => r.node.nodeId === this._selectedNodeId)
    if (!row) { el.innerHTML = ''; return }

    const r = row.report
    if (!r) {
      el.innerHTML = `
        <div class="md-panel">
          <div class="md-panel-header"><span>Findings — ${row.node.hostname || this._selectedNodeId}</span></div>
          <p class="cn-empty">ClusterDoctor unavailable for this node: ${row.error}</p>
        </div>`
      return
    }

    const profilesSection = this._editingProfiles
      ? `<form id="profileEditForm" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
           <input id="profileInput" type="text"
             value="${row.node.profiles.join(', ')}"
             placeholder="core, control-plane, storage, gateway"
             style="flex:1;min-width:200px;padding:4px 8px;border:1px solid var(--border-subtle-color);border-radius:6px;background:var(--surface-color);color:var(--on-surface-color);font-size:.84rem;"
           >
           <button type="submit" id="btnSaveProfiles" style="padding:3px 10px;border-radius:6px;border:none;background:var(--accent-color);color:#fff;font-size:.78rem;cursor:pointer;${this._savingProfiles ? 'opacity:.6;' : ''}">
             ${this._savingProfiles ? 'Saving…' : 'Save'}
           </button>
           <button type="button" id="btnCancelProfiles" style="padding:3px 10px;border-radius:6px;border:1px solid var(--border-subtle-color);background:transparent;color:var(--on-surface-color);font-size:.78rem;cursor:pointer;">
             Cancel
           </button>
           ${this._saveError ? `<span style="font-size:.78rem;color:var(--error-color)">${this._saveError}</span>` : ''}
         </form>`
      : `${profileTags(row.node.profiles)}
         <button id="btnEditProfiles" style="margin-left:8px;padding:2px 8px;border-radius:6px;border:1px solid var(--border-subtle-color);background:transparent;color:var(--secondary-text-color);font-size:.72rem;cursor:pointer;">
           Edit
         </button>`

    // Build health detail section
    const hd = this._healthDetail
    const healthSection = this._healthLoading
      ? `<div class="cn-section-label">Health Checks</div>
         <p class="cn-empty">Loading health detail…</p>`
      : this._healthError
        ? `<div class="cn-section-label">Health Checks</div>
           <p class="cn-empty">Could not load health detail: ${this._healthError}</p>`
        : hd ? `
           <div class="cn-section-label">
             Health Checks — ${statusBadge(hd.overallStatus)}
             ${hd.inventoryComplete ? '' : ' <span style="color:#f59e0b;font-size:.72rem;font-weight:400">(inventory incomplete)</span>'}
           </div>
           <table class="md-table">
             <thead>
               <tr>
                 <th></th>
                 <th>Subsystem</th>
                 <th>Status</th>
                 <th>Reason</th>
               </tr>
             </thead>
             <tbody>
               ${hd.checks.map((c: NodeHealthCheck) => `
               <tr>
                 <td><span class="cn-check-icon ${c.ok ? 'cn-check-ok' : 'cn-check-fail'}">${c.ok ? '✓' : '✕'}</span></td>
                 <td style="font-family:monospace;font-size:.78rem">${c.subsystem}</td>
                 <td>${c.ok
                   ? badge('OK', 'var(--success-color)')
                   : badge('FAIL', 'var(--error-color)')
                 }</td>
                 <td style="font-size:.82rem;color:var(--secondary-text-color)">${c.reason || '—'}</td>
               </tr>`).join('')}
             </tbody>
           </table>` : ''

    el.innerHTML = `
      <div class="cn-detail-panel">
        <div class="md-panel-header">
          <span>Findings — ${row.node.hostname || this._selectedNodeId}</span>
          <span style="font-size:.78rem;font-weight:400">${r.findings.length} finding${r.findings.length !== 1 ? 's' : ''} · heartbeat ${ageLabel(r.heartbeatAgeSeconds)} ago</span>
        </div>
        <div style="padding:12px 14px;display:flex;flex-direction:column;gap:10px;border-bottom:1px solid var(--border-subtle-color);">
          <div style="display:flex;align-items:baseline;gap:12px;font-size:.83rem;">
            <span style="min-width:80px;font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--secondary-text-color);">Profiles</span>
            ${profilesSection}
          </div>
          <div style="display:flex;align-items:baseline;gap:12px;font-size:.83rem;">
            <span style="min-width:80px;font-size:.72rem;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--secondary-text-color);">Hardware</span>
            ${capsLine(row.node.capabilities)}
          </div>
        </div>

        ${healthSection}

        ${r.findings.length > 0 ? `
        <div class="cn-section-label">Diagnostic Findings</div>
        <table class="md-table">
          <thead>
            <tr>
              <th>Severity</th>
              <th>Invariant</th>
              <th>Summary</th>
              <th>Evidence</th>
            </tr>
          </thead>
          <tbody>
            ${r.findings.map((f: Finding) => {
              const kv = f.evidence.length > 0 ? f.evidence[0].keyValues : {}
              const kvPairs = Object.entries(kv).slice(0, 4).map(([k, v]) => `${k}=${v}`).join(' ')
              return `
              <tr>
                <td>${badge(sevLabel(f.severity), sevColor(f.severity))}</td>
                <td style="font-family:monospace;font-size:.78rem">${f.invariantId}</td>
                <td>${f.summary}</td>
                <td class="cn-kv-list">${kvPairs || '—'}</td>
              </tr>`
            }).join('')}
          </tbody>
        </table>
        ` : `<p class="cn-empty">✓ No findings for this node.</p>`}
      </div>
    `

    // Wire profile edit controls
    el.querySelector('#btnEditProfiles')?.addEventListener('click', () => {
      this._editingProfiles = true
      this._saveError = ''
      this.renderDetail()
    })

    el.querySelector('#btnCancelProfiles')?.addEventListener('click', () => {
      this._editingProfiles = false
      this._saveError = ''
      this.renderDetail()
    })

    el.querySelector('#profileEditForm')?.addEventListener('submit', async (e) => {
      e.preventDefault()
      const input = (el.querySelector('#profileInput') as HTMLInputElement)?.value ?? ''
      const profiles = input.split(',').map(s => s.trim()).filter(Boolean)
      this._savingProfiles = true
      this._saveError = ''
      this.renderDetail()
      try {
        await setNodeProfiles(this._selectedNodeId, profiles)
        this._editingProfiles = false
        this._savingProfiles = false
        // Update the local row so the table reflects the change immediately
        const rowIdx = this._rows.findIndex(r => r.node.nodeId === this._selectedNodeId)
        if (rowIdx >= 0) this._rows[rowIdx].node.profiles = profiles
        this.render()
      } catch (err: any) {
        this._savingProfiles = false
        this._saveError = err?.message || 'Failed to save profiles'
        this.renderDetail()
      }
    })
  }
}

customElements.define('page-cluster-nodes', PageClusterNodes)
